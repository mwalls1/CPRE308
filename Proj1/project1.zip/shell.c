#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
char** string_parse(char* input);
int waitBackground();
int main(int argc, char** argv)
{
	char *input = malloc(sizeof(char) * 100); //Input from user
	char **args; //Argument array
	char *prompt = "308sh> ";
	char wd[256];
	int bg = 0;
	pid_t childPid;
	int returnStatus;
	if(argc !=1 && argc !=3){
		printf("Not enough arguments!\n");
		exit(0);
	}
	else if(argc == 3){
		if(strcmp(argv[1], "-p")!= 0){
			printf("No prompt given!\n");//Checks if the user gave -p without a prompt after
			exit(0);
		}
		else{
			prompt = argv[2];
		}
	}
	while(1){//while loop to creating constant polling for input
		printf("%s", prompt);
		size_t bufferLen = 100;
		getline(&input, &bufferLen, stdin);//retrieves data from user
	    args = string_parse(input);//adds the parsed input into the argument double pointer
		int k = 0;
		bg = 0;
		while(args[k] != NULL)//Checking if the arguments include a & for background process
		{
			if(strcmp(args[k], "&")==0)
			{
				bg = 1;
				args[k] = NULL;
				break;
				
			}
			k++;
		}
		if(strcmp(args[0], "")==0)//Do nothing if enter is pressed with no input
		{
			//do nothing
		}
		else if(strcmp(args[0], "cd")==0)//Changes directory to given path, or to the home directory
		{
			if(args[1]!=NULL)
			{
				chdir(args[1]);
			}
			else{
				chdir(getenv("HOME"));
			}
		}
		else if(strcmp(args[0],"pid")==0)//prints pid of the process
		{
			printf("%d\n", getpid());
		}
		else if(strcmp(args[0],"ppid")==0)//prints pid of the parent process
		{
			printf("%d\n", getppid());
		}
		else if(strcmp(args[0],"exit")==0)//exits the shell
		{
			printf("Goodbye!\n");
			exit(0);
		}
		else if(strcmp(args[0],"pwd")==0)//prints the working directory
		{
			getcwd(wd, sizeof(wd));
			printf("%s\n", wd);
		}
		else
		{
			childPid = fork();//calling execvp requires a fork to keep the parent process alive
			if(childPid == 0)//the child process runs the execvp command
			{
				int error = execvp(args[0],args);//error checking execvp
				printf("Cannot exec %s: No such file or directory\n", args[0]);//print an error if one occurs
				exit(error);
			}
			else
			{
				printf("[%d] ", childPid);
				printf("%s\n", args[0]);//print the pid and argument name
				if(!bg)
				{
					waitpid(childPid,&returnStatus,0);//wait for the child process to end if its not a background process
					if(WIFEXITED(returnStatus))
					{
						printf("[%d] %s Exit %d\n", childPid, args[0],WEXITSTATUS(returnStatus));//return the exit status
					}
					else
					{
						printf("[%d] %s Exit %d\n", childPid, args[0], WTERMSIG(returnStatus));//return the exit status
					}
				}
			}
		 }
		 waitBackground();
		
	}
}
int waitBackground()//checks for background processes closing
{
	int status;
	int pid = waitpid(-1, &status, WNOHANG);//checks to see if any background processes have closed
	if(pid > 0)
	{
		if(WIFEXITED(status))
		{
			printf("[%d] Exit %d\n", pid,WEXITSTATUS(status));//print exit status
		}
		else
		{
			printf("[%d] Exit %d\n", pid, WTERMSIG(status));//print exit status
		}
        return 0;
	}
	else
	{
		return 0;
	}
}
char** string_parse(char* input)//parses input into seperate strings for execvp
{
	char** arguments = malloc(100*sizeof(char*));
	char *delim = " ";//seperate each argument from the string
	char *ptr = malloc(100 * sizeof(char));
	ptr =  strtok(input, delim);//set the ptr to the first word in the input string
	if(ptr[strlen(ptr)-1] == '\n')
	{
		ptr[strlen(ptr)-1] = '\0';//adds an appropiate null character to the pointer
	}
	else
	{
		ptr[strlen(ptr)] = '\0';//adds an appropiate null character to the pointer
	}
	arguments[0] = ptr;//store ptr into the arguments double pointer
	int i = 1;
	ptr = strtok(NULL, delim);//set pointer to next value
	while(ptr != NULL)//loop through each argument until we hit the end "NULL"
	{
		if(ptr[strlen(ptr)-1] == '\n')
		{
			ptr[strlen(ptr)-1] = '\0';//adds an appropiate null character to the pointer
		}
		else
		{
			ptr[strlen(ptr)] = '\0';//adds an appropiate null character to the pointer
		}
		arguments[i] = ptr;//store ptr into the arguments double pointer
		ptr = strtok(NULL, delim);//set pointer to next value
		i++;//increment i to get the proper arguments array location
	}
        arguments[i] = NULL;//set the last spot to null because of execvp standards
	return arguments;
}
